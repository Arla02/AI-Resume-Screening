<div align=center>
 
# 🚀 Condi botnet Ver 6 🚀

<p align="center">  <a href="https://t.me/imperium_en"><img width="160" height="50" src="https://i.imgur.com/N7AK7XY.png"></a></p>

# README
I did not create CondiV6 All Credits to Zxcr9999<br>
This source Leaked By t.me/iotbotnets


# Setup
```sh
Setup in tut.txt
```

# Upload for educational only

Enjoy!
