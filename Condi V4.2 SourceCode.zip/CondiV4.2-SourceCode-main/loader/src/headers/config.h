#pragma once

#define HTTP_SERVER "23.224.131.230"
#define HTTP_PORT 80

#define TFTP_SERVER "23.224.131.230"
